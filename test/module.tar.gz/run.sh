#!/usr/bin/env bash
set -euo pipefile
echo running
